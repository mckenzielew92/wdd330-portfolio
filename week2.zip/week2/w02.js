function addNumbers(){
    //collects numbers from input id input1
    let x = parseInt(document.getElementById("input1").value);
    //defines output value
    let output = 0;
    //creates loop for i to = to input1 value
    if (isNaN(x)) {
        alert("Invalid input Please use a number");
    } else {
        for (let i = 0; i <= x; i++) {
            //adds i current value you output
            output += i;
        }
    }
    
    //take let output and places it to the div output.
    document.getElementById("output1").innerHTML = output;
}


    // take let output and places it to the div output.
    document.getElementById("outputOne").innerHTML = output;
}

function addNumber2(){
    //collects number from id input1
    let x = parseInt(document.getElementById("input1").value);
    //collects number from id input2
    let y = parseInt(document.getElementById("input2").value);
    //adds x and y together for output
    let output = x + y
    //take let output and places it to the div output.
    document.getElementById("output2").innerHTML = output;
}

